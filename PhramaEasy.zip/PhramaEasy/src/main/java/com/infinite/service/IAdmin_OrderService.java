package com.infinite.service;

import java.util.List;

import com.infinite.model.OrderList;



public interface IAdmin_OrderService {
	public List<OrderList> getOrderHistory();
}
