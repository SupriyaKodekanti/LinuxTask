package com.infinite.service;

import java.util.List;
import com.infinite.model.CustomerLogin;


public interface IAdminuserlistService {
	public List<CustomerLogin> getUsers();

}
